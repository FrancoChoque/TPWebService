#ifndef TYPES__H__
#define TYPES__H__ 

#include <stdio.h>

typedef char** queue_t;


#endif