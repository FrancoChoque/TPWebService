#include <stdio.h>
#include "errors.h"

const char* error_msg[] = {
		MSG_OK;
		MSG_ERROR_NULL_POINTER;
		MSG_ERROR_INVALID_ARGUMENTS;
		MSG_ERROR_MEMORY_SHORTAGE;

};