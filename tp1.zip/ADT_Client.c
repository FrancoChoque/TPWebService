#include "ADT_Client.h"

int client_create(){


}

int client_destroy(client*){
	
}